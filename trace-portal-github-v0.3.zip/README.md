# Trace Portal

Trace 的认知变化工作台原型。页面以 TRACE 产品定义 v0.3 与
Tracehackthon/trace_backend 的公开产品边界为依据，呈现候选变化、用户采用、
能力发布、来源授权、激活回执、验证和恢复。

## 本地运行

```bash
npm install
npm run build
npm run dev
```

`npm run dev` 会预览最近一次生产构建，默认地址为
`http://localhost:4173/`。修改源码后先运行 `npm run build`。

## 页面

- 工作台：认知变化列表、本轮激活回执、搜索与状态筛选
- 待处理：用户需要决定或复核的候选
- 时间线：从保留现场到验证/发布的审计事件
- 来源：Agent 现场与外部前例的授权范围
- 能力：已确认判断的规则、清单或 Skill 发布
- 健康：状态链路、隐私边界与恢复点

当前数据为前端演示数据。页面未连接线上后端，也不会上传原始 prompt 或来源正文。

## 上传 GitHub 并发布

1. 在 GitHub 新建一个空仓库，不勾选自动生成 README。
2. 将本源码包解压后的所有内容上传到仓库根目录，默认分支使用 `main`。
3. 打开仓库的 `Settings > Pages`。
4. 在 `Build and deployment` 的 `Source` 中选择 `GitHub Actions`。
5. 打开仓库的 `Actions` 页面，等待 `Deploy Trace to GitHub Pages` 完成。

发布地址通常为 `https://你的用户名.github.io/仓库名/`。
