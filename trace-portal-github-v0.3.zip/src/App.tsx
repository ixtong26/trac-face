import { FormEvent, ReactNode, useMemo, useState } from 'react'
import {
  Activity, ArchiveRestore, ArrowRight, Bell, BookOpen, Bot, Check, CheckCircle2,
  ChevronDown, CircleDashed, Clock3, Command, Database, FileCheck2, FileText,
  Filter, GitBranch, HeartPulse, Inbox, Layers3, Link2, ListChecks, MoreHorizontal,
  Plus, RotateCcw, Search, ShieldCheck, Sparkles, X,
} from 'lucide-react'

type NavId = 'work' | 'inbox' | 'timeline' | 'sources' | 'abilities' | 'health'
type ChangeState = '待确认' | '已采用' | '需回顾' | '已发布'

type Change = {
  id: string
  title: string
  area: string
  state: ChangeState
  confidence: number
  trigger: string
  source: string
  before: string
  after: string
  scope: string
  activation: string
  validation: string
  adoptedBy: string[]
  evidence: number
  review: string
  updated: string
}

const initialChanges: Change[] = [
  {
    id: 'T-042',
    title: '检索结果必须附带可追溯证据',
    area: 'Research agent',
    state: '待确认',
    confidence: 78,
    trigger: 'Cursor 实验 #18 · 失败复盘',
    source: 'Cursor / research-agent',
    before: '将来源链接视为可选附注',
    after: '将可验证来源作为回答质量的组成部分',
    scope: '研究、事实核验与需要复盘的方案判断；不适用于纯创意发散。',
    activation: '任务包含“调研、比较、证据、出处”时带回。',
    validation: '下一次交付中，关键事实均能在 2 步内回到原始来源。',
    adoptedBy: ['林岚', 'Mira'],
    evidence: 4,
    review: '9 月 18 日',
    updated: '今天 09:42',
  },
  {
    id: 'T-041',
    title: '复杂任务先显式陈述不确定性',
    area: 'Codex orchestrator',
    state: '已采用',
    confidence: 91,
    trigger: 'Claude 工作会话 · 结果复盘',
    source: 'Claude / launch-review',
    before: '直接输出单一路径的结论',
    after: '先标出假设、边界与待验证项，再给出行动路径',
    scope: '跨系统、长周期或输入不完整的复杂任务。',
    activation: '检测到多个依赖或关键输入缺失时带回。',
    validation: '评审者无需追问即可区分事实、假设和建议。',
    adoptedBy: ['林岚', 'Jon', 'Mira'],
    evidence: 7,
    review: '10 月 02 日',
    updated: '昨天 16:10',
  },
  {
    id: 'T-039',
    title: '多代理交接以决策卡代替聊天摘要',
    area: 'Product team',
    state: '需回顾',
    confidence: 64,
    trigger: '团队讨论 · 交接失败案例',
    source: 'Team / weekly-sync',
    before: '交接时同步完整对话上下文',
    after: '只同步仍然有效的决策、证据、边界与待办',
    scope: '多 Agent 或多人跨时段接力的任务。',
    activation: '发生 owner 变化、会话切换或任务委派时带回。',
    validation: '接手者能独立复述决策边界，并继续完成下一步。',
    adoptedBy: ['Jon'],
    evidence: 2,
    review: '今天',
    updated: '8 月 24 日',
  },
  {
    id: 'T-036',
    title: '先保留模糊感受，再追问它属于哪类问题',
    area: 'Product discovery',
    state: '已发布',
    confidence: 86,
    trigger: 'ChatGPT 产品讨论 · 访谈回看',
    source: 'ChatGPT / product-discovery',
    before: '要求用户先给出完整、清楚的结论',
    after: '先保留原话与现场，再区分目标、表达、证据、场景或判断问题',
    scope: '产品发现、学习复盘与表达被误解的场景。',
    activation: '出现“说不清”“哪里不对”“好像”时带回。',
    validation: '讨论后能形成可确认的 Before / After 判断。',
    adoptedBy: ['林岚', 'Jon', 'Mira'],
    evidence: 6,
    review: '10 月 12 日',
    updated: '8 月 21 日',
  },
]

const navItems: { id: NavId; label: string; icon: typeof Layers3; count?: number }[] = [
  { id: 'work', label: '工作台', icon: Layers3 },
  { id: 'inbox', label: '待处理', icon: Inbox, count: 3 },
  { id: 'timeline', label: '时间线', icon: Clock3 },
  { id: 'sources', label: '来源', icon: BookOpen },
  { id: 'abilities', label: '能力', icon: Sparkles },
  { id: 'health', label: '健康', icon: HeartPulse },
]

const sourceRows = [
  { name: 'Codex', kind: 'Agent 现场', scope: '当前项目', status: '已授权', detail: '3 个受控读取指针', updated: '2 分钟前', icon: Command },
  { name: 'Claude Code', kind: 'Agent 现场', scope: '当前项目', status: '已授权', detail: '只读引用 · 不保存正文', updated: '1 小时前', icon: Bot },
  { name: 'Cursor', kind: 'Agent 现场', scope: 'research-agent', status: '已授权', detail: '2 个候选前例', updated: '昨天', icon: FileText },
  { name: '知乎收藏', kind: '外部前例', scope: '手动选择', status: '待校验', detail: '仅作为对照，不自动采用', updated: '8 月 28 日', icon: Link2 },
]

const timelineRows = [
  { time: '今天 09:42', title: '形成候选判断', detail: 'Cursor 实验 #18 的失败复盘被整理为 T-042。', tone: 'emerald' },
  { time: '今天 09:38', title: '保留现场', detail: '记录原话、项目状态和 4 条可追溯证据，未保存完整对话。', tone: 'slate' },
  { time: '昨天 16:10', title: '确认采用', detail: '3 位协作者采用 T-041，适用范围限定为复杂任务。', tone: 'emerald' },
  { time: '8 月 30 日', title: '发布能力', detail: 'T-036 编译为项目检查清单，可被 Codex 激活。', tone: 'emerald' },
  { time: '8 月 24 日', title: '等待复核', detail: 'T-039 缺少跨项目迁移证据，进入回顾队列。', tone: 'amber' },
]

const stateStyle: Record<ChangeState, string> = {
  待确认: 'bg-[#ecfdf5] text-[#08775a] border-[#ccefe3]',
  已采用: 'bg-[#eff6ff] text-[#2563a8] border-[#d8e8fb]',
  需回顾: 'bg-[#fff7e8] text-[#9a5d09] border-[#f4dfb4]',
  已发布: 'bg-[#e6f7f0] text-[#075f49] border-[#bde5d5]',
}

function StatusBadge({ state }: { state: ChangeState }) {
  return <span className={'inline-flex h-6 items-center rounded-full border px-2.5 text-[11px] font-semibold ' + stateStyle[state]}>{state}</span>
}

function AvatarStack({ names }: { names: string[] }) {
  const colors = ['bg-[#117a5a]', 'bg-[#2563a8]', 'bg-[#a05f0a]', 'bg-[#56616b]']
  return <div className='flex -space-x-2'>{names.map((name, i) => <div key={name + i} title={name} className={'grid h-7 w-7 place-items-center rounded-full border-2 border-white text-[10px] font-bold text-white ' + colors[i % colors.length]}>{name.slice(0, 1)}</div>)}</div>
}

function SectionHeader({ eyebrow, title, copy, action }: { eyebrow: string; title: string; copy: string; action?: ReactNode }) {
  return <header className='mb-6 flex flex-wrap items-start justify-between gap-4'>
    <div>
      <p className='mb-2 text-[11px] font-semibold uppercase text-[#708077]'>{eyebrow}</p>
      <h1 className='text-[26px] font-semibold leading-tight text-[#10231c]'>{title}</h1>
      <p className='mt-2 max-w-2xl text-sm leading-6 text-[#65736c]'>{copy}</p>
    </div>
    {action}
  </header>
}

function ChangeList({ changes, selectedId, onSelect }: { changes: Change[]; selectedId: string; onSelect: (id: string) => void }) {
  if (!changes.length) {
    return <div className='border-y border-[#e4ebe7] py-16 text-center'>
      <Search className='mx-auto h-5 w-5 text-[#92a39a]' />
      <p className='mt-3 text-sm font-semibold text-[#273b33]'>没有匹配的认知变化</p>
      <p className='mt-1 text-xs text-[#75827c]'>调整搜索或筛选条件后再试。</p>
    </div>
  }
  return <div className='overflow-hidden rounded-lg border border-[#dfe8e3] bg-white'>
    {changes.map((change, index) => (
      <button key={change.id} onClick={() => onSelect(change.id)} className={'group flex w-full items-center gap-4 px-4 py-4 text-left transition hover:bg-[#f6fbf8] ' + (index ? 'border-t border-[#e8eeeb] ' : '') + (selectedId === change.id ? 'bg-[#f0faf5] shadow-[inset_3px_0_0_#14966f]' : '')}>
        <div className='grid h-10 w-10 shrink-0 place-items-center rounded-lg border border-[#dce9e3] bg-[#f4faf7] text-[#17825f]'><GitBranch className='h-[18px] w-[18px]' /></div>
        <div className='min-w-0 flex-1'>
          <div className='flex flex-wrap items-center gap-2'><span className='font-semibold text-[#1a2d25]'>{change.title}</span><StatusBadge state={change.state} /></div>
          <p className='mt-1 truncate text-xs text-[#718078]'>{change.id} · {change.trigger} · {change.area}</p>
        </div>
        <div className='hidden min-w-[70px] text-right sm:block'><p className='text-sm font-semibold tabular-nums text-[#1f342b]'>{change.confidence}%</p><p className='text-[11px] text-[#87948e]'>证据置信度</p></div>
        <ArrowRight className='h-4 w-4 shrink-0 text-[#9caaa3] transition group-hover:translate-x-0.5 group-hover:text-[#14795b]' />
      </button>
    ))}
  </div>
}

function TraceMark() {
  return <div className='grid h-9 w-9 place-items-center rounded-lg bg-[#0f6b4f] text-white shadow-[0_7px_18px_rgba(15,107,79,0.2)]'><Command className='h-[18px] w-[18px]' /></div>
}

export default function App() {
  const [activeNav, setActiveNav] = useState<NavId>('work')
  const [changes, setChanges] = useState(initialChanges)
  const [selectedId, setSelectedId] = useState('T-042')
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<'全部' | ChangeState>('全部')
  const [notice, setNotice] = useState('')
  const [recordOpen, setRecordOpen] = useState(false)
  const [mobileDetailOpen, setMobileDetailOpen] = useState(false)
  const [published, setPublished] = useState<string[]>([])
  const [doctorState, setDoctorState] = useState<'idle' | 'running' | 'done'>('idle')

  const visibleChanges = useMemo(() => changes.filter(change => {
    const matchesFilter = filter === '全部' || change.state === filter
    const haystack = (change.title + change.area + change.trigger + change.id).toLowerCase()
    return matchesFilter && haystack.includes(query.trim().toLowerCase())
  }), [changes, filter, query])
  const selected = changes.find(change => change.id === selectedId) || changes[0]

  const selectChange = (id: string) => {
    setSelectedId(id)
    setMobileDetailOpen(true)
  }

  const adoptSelected = () => {
    setChanges(current => current.map(change => change.id === selected.id ? { ...change, state: '已采用', adoptedBy: [...new Set([...change.adoptedBy, '你'])] } : change))
    setNotice('已采用「' + selected.title + '」，下一次符合激活条件的任务将带回这条判断。')
  }

  const holdSelected = () => {
    setChanges(current => current.map(change => change.id === selected.id ? { ...change, state: '需回顾' } : change))
    setNotice('已将「' + selected.title + '」暂存到回顾队列。')
  }

  const publishAbility = (id: string) => {
    setPublished(current => [...new Set([...current, id])])
    setNotice('能力发布已记录；发布范围限定在当前项目。')
  }

  const runDoctor = () => {
    setDoctorState('running')
    window.setTimeout(() => setDoctorState('done'), 800)
  }

  const createCandidate = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const signal = String(form.get('signal') || '').trim()
    const area = String(form.get('area') || '').trim()
    if (!signal) return
    const nextNumber = Math.max(...changes.map(change => Number(change.id.slice(2)))) + 1
    const created: Change = {
      id: 'T-' + String(nextNumber).padStart(3, '0'),
      title: signal.length > 30 ? signal.slice(0, 30) + '…' : signal,
      area: area || '待确认范围',
      state: '待确认',
      confidence: 52,
      trigger: '手动记录 · 当前工作现场',
      source: 'Trace workspace',
      before: '尚未澄清原有判断',
      after: '等待继续讨论形成候选判断',
      scope: '需要在讨论中确认适用与不适用的边界。',
      activation: '尚未设置激活条件。',
      validation: '尚未设置验证方式。',
      adoptedBy: [],
      evidence: 1,
      review: '未设置',
      updated: '刚刚',
    }
    setChanges(current => [created, ...current])
    setSelectedId(created.id)
    setRecordOpen(false)
    setNotice('已保留原话与现场；Trace 不会把它自动写成已采用判断。')
  }

  const workView = <div>
    <SectionHeader eyebrow='WORKSPACE / WORK' title='正在发生的认知变化' copy='把真实工作里形成的判断做成可审阅候选，再决定是否带进未来。' action={<button onClick={() => setRecordOpen(true)} className='inline-flex h-9 items-center gap-2 rounded-lg bg-[#0f7657] px-3.5 text-sm font-semibold text-white transition hover:bg-[#0a6047]'><Plus className='h-4 w-4' />记录变化</button>} />
    <section className='mb-5 border-y border-[#cfe7dc] bg-[#f0faf5] px-5 py-5'>
      <div className='flex flex-wrap items-start justify-between gap-5'>
        <div className='max-w-2xl'>
          <div className='mb-2 flex items-center gap-2 text-xs font-semibold text-[#137657]'><Activity className='h-4 w-4' />本轮工作回执</div>
          <h2 className='text-xl font-semibold leading-7 text-[#123126]'>过去的 3 条判断已进入当前 Codex 工作现场</h2>
          <p className='mt-2 text-sm leading-6 text-[#587168]'>只激活版本化引用与受控读取指针；未注入完整聊天、Wiki 正文或未经确认的候选。</p>
        </div>
        <div className='flex gap-8'><div><p className='text-2xl font-semibold tabular-nums text-[#123126]'>04</p><p className='mt-1 text-[11px] text-[#71847b]'>活跃变化</p></div><div><p className='text-2xl font-semibold tabular-nums text-[#a35e00]'>03</p><p className='mt-1 text-[11px] text-[#71847b]'>待你决定</p></div></div>
      </div>
      <div className='mt-5 grid grid-cols-2 overflow-hidden rounded-lg border border-[#d4e8de] bg-white text-xs sm:grid-cols-4'>
        {['保留现场', '继续讨论', '用户确认', '下次带回'].map((item, index) => <div key={item} className={'flex items-center gap-2 px-3 py-3 ' + (index ? 'border-l border-[#e0ebe5]' : '')}><span className={'grid h-5 w-5 place-items-center rounded-full text-[10px] font-bold ' + (index < 2 ? 'bg-[#14795b] text-white' : 'bg-[#e7f4ee] text-[#14795b]')}>{index + 1}</span><span className='truncate font-medium text-[#43594f]'>{item}</span></div>)}
      </div>
    </section>
    <div className='mb-4 flex flex-wrap items-center gap-3'>
      <div className='relative min-w-[220px] flex-1'><Search className='absolute left-3 top-2.5 h-4 w-4 text-[#829088]' /><input value={query} onChange={event => setQuery(event.target.value)} placeholder='搜索变化、现场或适用范围' className='h-9 w-full rounded-lg border border-[#dce6e1] bg-white pl-9 pr-3 text-sm text-[#21342c] outline-none transition placeholder:text-[#96a39d] focus:border-[#62af92] focus:ring-2 focus:ring-[#dff4ea]' /></div>
      <div className='flex items-center gap-1 rounded-lg border border-[#dce6e1] bg-white p-1'><Filter className='ml-2 h-3.5 w-3.5 text-[#7f8c86]' />{(['全部', '待确认', '已采用', '需回顾'] as const).map(item => <button key={item} onClick={() => setFilter(item)} className={'h-7 rounded-md px-2.5 text-xs font-medium transition ' + (filter === item ? 'bg-[#e8f5ef] text-[#116a50]' : 'text-[#6f7e77] hover:text-[#273a32]')}>{item}</button>)}</div>
    </div>
    <ChangeList changes={visibleChanges} selectedId={selectedId} onSelect={selectChange} />
  </div>

  const inboxView = <div>
    <SectionHeader eyebrow='DECISION INBOX' title='等待你决定的变化' copy='Agent 可以提出候选，但不能替你采用。先看触发现场、边界与风险，再做决定。' />
    <div className='mb-5 grid grid-cols-3 gap-px overflow-hidden rounded-lg border border-[#dfe8e3] bg-[#dfe8e3]'>
      {[['03', '等待决定'], ['01', '今天到期'], ['02', '缺少证据']].map(row => <div key={row[1]} className='bg-white px-4 py-4'><p className='text-xl font-semibold tabular-nums text-[#173229]'>{row[0]}</p><p className='mt-1 text-xs text-[#78857f]'>{row[1]}</p></div>)}
    </div>
    <ChangeList changes={changes.filter(change => change.state === '待确认' || change.state === '需回顾')} selectedId={selectedId} onSelect={selectChange} />
  </div>

  const timelineView = <div>
    <SectionHeader eyebrow='CHANGE LOG' title='从现场到下一次行动' copy='只展示可审计的生命周期事件，不把完整对话和隐藏推理伪装成认知来源。' />
    <div className='border-t border-[#dfe8e3]'>{timelineRows.map((row, index) => <div key={row.time + row.title} className='grid grid-cols-[92px_24px_1fr] gap-3 border-b border-[#e6ece9] py-5'>
      <time className='pt-0.5 text-xs leading-5 text-[#78867f]'>{row.time}</time>
      <div className='relative flex justify-center'><span className={'z-10 mt-1 h-2.5 w-2.5 rounded-full border-2 border-white ' + (row.tone === 'amber' ? 'bg-[#c27a19]' : row.tone === 'slate' ? 'bg-[#7b8881]' : 'bg-[#14966f]')} />{index < timelineRows.length - 1 && <span className='absolute bottom-[-21px] top-3 w-px bg-[#d8e4de]' />}</div>
      <div><p className='text-sm font-semibold text-[#24372f]'>{row.title}</p><p className='mt-1 text-sm leading-6 text-[#6b7972]'>{row.detail}</p></div>
    </div>)}</div>
  </div>

  const sourcesView = <div>
    <SectionHeader eyebrow='AUTHORIZED SOURCES' title='来源与现场' copy='来源提供证据和前例，不自动成为真理。默认只保留引用、版本与用途，需要时再按授权读取。' action={<button onClick={() => setNotice('连接入口已打开；新来源将先进入授权与范围确认。')} className='inline-flex h-9 items-center gap-2 rounded-lg border border-[#cddbd4] bg-white px-3.5 text-sm font-semibold text-[#285043] hover:bg-[#f5faf7]'><Plus className='h-4 w-4' />连接来源</button>} />
    <div className='overflow-hidden rounded-lg border border-[#dfe8e3] bg-white'>
      <div className='hidden grid-cols-[1.3fr_.8fr_.8fr_.7fr] gap-3 border-b border-[#e5ece8] bg-[#f7faf8] px-4 py-2.5 text-[11px] font-semibold text-[#7b8882] sm:grid'><span>来源</span><span>授权范围</span><span>状态</span><span>最近活动</span></div>
      {sourceRows.map((source, index) => <div key={source.name} className={'grid items-center gap-3 px-4 py-4 sm:grid-cols-[1.3fr_.8fr_.8fr_.7fr] ' + (index ? 'border-t border-[#e7edea]' : '')}>
        <div className='flex min-w-0 items-center gap-3'><div className='grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-[#eff8f3] text-[#157b5c]'><source.icon className='h-[17px] w-[17px]' /></div><div className='min-w-0'><p className='text-sm font-semibold text-[#25382f]'>{source.name}</p><p className='truncate text-xs text-[#84908a]'>{source.kind} · {source.detail}</p></div></div>
        <p className='text-xs text-[#5f7168]'>{source.scope}</p>
        <span className={'w-fit rounded-full border px-2 py-1 text-[11px] font-semibold ' + (source.status === '已授权' ? 'border-[#cbe9dc] bg-[#edf9f3] text-[#127052]' : 'border-[#f0ddb5] bg-[#fff8ea] text-[#99600d]')}>{source.status}</span>
        <p className='text-xs text-[#7b8882]'>{source.updated}</p>
      </div>)}
    </div>
    <div className='mt-5 flex gap-3 border-l-2 border-[#70b99d] bg-[#f4faf7] px-4 py-3 text-xs leading-5 text-[#52685e]'><ShieldCheck className='mt-0.5 h-4 w-4 shrink-0 text-[#14795b]' /><span>原始 prompt、完整来源正文、凭证与工具参数不会进入运行日志；读取指针仅授权给当前进程。</span></div>
  </div>

  const abilityRows = [
    { id: 'A-012', title: '复杂任务不确定性检查', format: '项目检查清单', source: 'T-041', scope: 'trace-web', state: '已发布' },
    { id: 'A-011', title: '模糊感受澄清协议', format: 'Agent Skill', source: 'T-036', scope: '全局', state: '已发布' },
    { id: 'A-013', title: '可追溯检索规范', format: '项目规则', source: 'T-042', scope: 'research-agent', state: '待发布' },
  ]
  const abilitiesView = <div>
    <SectionHeader eyebrow='PUBLISHED ABILITIES' title='给未来 Agent 的长期能力' copy='能力来自已确认、仍适用的判断。发布格式可以是规则、清单或 Skill，但它们都保留来源、范围和撤销路径。' />
    <div className='space-y-3'>{abilityRows.map(ability => {
      const isPublished = ability.state === '已发布' || published.includes(ability.id)
      return <div key={ability.id} className='flex flex-wrap items-center gap-4 rounded-lg border border-[#dfe8e3] bg-white px-4 py-4'>
        <div className='grid h-10 w-10 place-items-center rounded-lg bg-[#eaf7f1] text-[#117658]'><Sparkles className='h-[18px] w-[18px]' /></div>
        <div className='min-w-[220px] flex-1'><div className='flex items-center gap-2'><p className='text-sm font-semibold text-[#23372e]'>{ability.title}</p><span className={'rounded-full px-2 py-1 text-[11px] font-semibold ' + (isPublished ? 'bg-[#e8f6ef] text-[#116f52]' : 'bg-[#fff6e7] text-[#97600e]')}>{isPublished ? '已发布' : '待发布'}</span></div><p className='mt-1 text-xs text-[#7a8881]'>{ability.id} · 来自 {ability.source} · {ability.format}</p></div>
        <div className='text-right'><p className='text-xs font-medium text-[#40564c]'>{ability.scope}</p><p className='mt-1 text-[11px] text-[#8a9690]'>发布范围</p></div>
        <button disabled={isPublished} onClick={() => publishAbility(ability.id)} className='h-8 rounded-lg border border-[#ccdcd4] px-3 text-xs font-semibold text-[#17694f] hover:bg-[#f0f8f4] disabled:cursor-default disabled:border-transparent disabled:text-[#7d8983]'>{isPublished ? '查看版本' : '确认发布'}</button>
      </div>
    })}</div>
  </div>

  const healthView = <div>
    <SectionHeader eyebrow='SYSTEM HEALTH' title='可核验，也可恢复' copy='健康检查只验证状态链路、版本与完整性，不展示敏感正文。备份和恢复均经过 staging 校验。' action={<button onClick={runDoctor} disabled={doctorState === 'running'} className='inline-flex h-9 items-center gap-2 rounded-lg bg-[#0f7657] px-3.5 text-sm font-semibold text-white disabled:opacity-60'><HeartPulse className='h-4 w-4' />{doctorState === 'running' ? '检查中…' : '运行 Doctor'}</button>} />
    <div className='grid gap-3 sm:grid-cols-2'>{[
      { icon: Database, label: '状态库完整性', value: doctorState === 'done' ? '已通过' : '正常', copy: 'revision 与 hash 链一致' },
      { icon: GitBranch, label: 'Lineage', value: '17 / 17', copy: '所有候选均可追溯' },
      { icon: ShieldCheck, label: '隐私边界', value: '0 泄漏', copy: '运行日志未发现敏感 payload' },
      { icon: ArchiveRestore, label: '最近备份', value: '今天 08:00', copy: '已通过 staging 验证' },
    ].map(item => <div key={item.label} className='flex items-start gap-4 rounded-lg border border-[#dfe8e3] bg-white p-4'><div className='grid h-9 w-9 place-items-center rounded-lg bg-[#eff8f3] text-[#14795b]'><item.icon className='h-[17px] w-[17px]' /></div><div><p className='text-xs font-medium text-[#708078]'>{item.label}</p><p className='mt-1 text-base font-semibold text-[#20352c]'>{item.value}</p><p className='mt-1 text-xs text-[#84918b]'>{item.copy}</p></div></div>)}</div>
    {doctorState === 'done' && <div className='mt-4 flex items-center gap-3 border border-[#cde9dc] bg-[#eefaf4] px-4 py-3 text-sm text-[#17684f]'><CheckCircle2 className='h-5 w-5' />检查完成：项目状态、来源指针、回执与备份均可验证。</div>}
    <section className='mt-7 border-t border-[#dfe8e3] pt-5'><div className='flex items-center justify-between'><div><h2 className='text-sm font-semibold text-[#283a32]'>恢复点</h2><p className='mt-1 text-xs text-[#7c8983]'>最近 3 个经过完整性校验的项目备份</p></div><button onClick={() => setNotice('已创建新的加密项目备份，并完成 staging 验证。')} className='inline-flex items-center gap-2 text-xs font-semibold text-[#137255]'><ArchiveRestore className='h-4 w-4' />创建备份</button></div>
      <div className='mt-4 divide-y divide-[#e7edea] border-y border-[#e2e9e5]'>{['2026-09-10 · 08:00', '2026-09-09 · 18:30', '2026-09-08 · 09:15'].map((date, index) => <div key={date} className='flex items-center gap-3 py-3 text-xs'><FileCheck2 className='h-4 w-4 text-[#4f806d]' /><span className='font-medium text-[#3d5148]'>{date}</span><span className='ml-auto text-[#84918b]'>{index === 0 ? '自动备份' : '手动备份'} · 已验证</span></div>)}</div>
    </section>
  </div>

  const mainContent = activeNav === 'work' ? workView : activeNav === 'inbox' ? inboxView : activeNav === 'timeline' ? timelineView : activeNav === 'sources' ? sourcesView : activeNav === 'abilities' ? abilitiesView : healthView
  const showInspector = activeNav === 'work' || activeNav === 'inbox'

  const detailPanel = <div className='flex h-full flex-col bg-white'>
    <div className='flex items-center justify-between border-b border-[#e3eae6] px-5 py-4'><div><p className='text-[11px] font-semibold uppercase text-[#7b8882]'>CHANGE INSPECTOR</p><p className='mt-1 text-xs text-[#a0aaa5]'>{selected.id} · 更新于 {selected.updated}</p></div><div className='flex items-center gap-1'><button aria-label='更多操作' className='grid h-8 w-8 place-items-center rounded-md text-[#77847e] hover:bg-[#f2f7f4]'><MoreHorizontal className='h-4 w-4' /></button><button aria-label='关闭详情' onClick={() => setMobileDetailOpen(false)} className='grid h-8 w-8 place-items-center rounded-md text-[#77847e] hover:bg-[#f2f7f4] xl:hidden'><X className='h-4 w-4' /></button></div></div>
    <div className='min-h-0 flex-1 overflow-y-auto px-5 py-5'>
      <div className='mb-3 flex items-center gap-2'><StatusBadge state={selected.state} /><span className='text-xs font-medium text-[#87948e]'>{selected.confidence}% 置信度</span></div>
      <h2 className='text-lg font-semibold leading-6 text-[#172c23]'>{selected.title}</h2>
      <p className='mt-2 text-sm leading-6 text-[#65756d]'>适用于 <span className='font-semibold text-[#365349]'>{selected.area}</span> 的协作判断。</p>
      <section className='mt-5 border-y border-[#dfe8e3] py-4'>
        <div className='grid grid-cols-[28px_1fr] gap-2'><span className='grid h-6 w-6 place-items-center rounded-full bg-[#edf2ef] text-[10px] font-bold text-[#52655c]'>B</span><div><p className='text-[10px] font-semibold uppercase text-[#8b9791]'>Before</p><p className='mt-1 text-sm leading-5 text-[#3d5047]'>{selected.before}</p></div></div>
        <div className='ml-3 h-5 w-px bg-[#cbded5]' />
        <div className='grid grid-cols-[28px_1fr] gap-2'><span className='grid h-6 w-6 place-items-center rounded-full bg-[#14795b] text-[10px] font-bold text-white'>A</span><div><p className='text-[10px] font-semibold uppercase text-[#14795b]'>After</p><p className='mt-1 text-sm font-medium leading-5 text-[#1d352b]'>{selected.after}</p></div></div>
      </section>
      <section className='border-b border-[#e4ebe7] py-4'><h3 className='text-xs font-semibold text-[#31463c]'>触发现场</h3><div className='mt-3 flex gap-3'><FileText className='mt-0.5 h-4 w-4 shrink-0 text-[#b47218]' /><div><p className='text-sm font-medium text-[#364a41]'>{selected.trigger}</p><p className='mt-1 text-xs leading-5 text-[#7b8882]'>{selected.source} · {selected.evidence} 条证据</p></div></div></section>
      <section className='border-b border-[#e4ebe7] py-4'><h3 className='text-xs font-semibold text-[#31463c]'>适用边界</h3><p className='mt-2 text-xs leading-5 text-[#65756d]'>{selected.scope}</p></section>
      <section className='border-b border-[#e4ebe7] py-4'><h3 className='text-xs font-semibold text-[#31463c]'>激活与验证</h3><div className='mt-3 space-y-3 text-xs leading-5'><div className='flex gap-2'><CircleDashed className='mt-0.5 h-4 w-4 shrink-0 text-[#18805f]' /><p><span className='font-semibold text-[#455b50]'>何时带回：</span><span className='text-[#6d7c75]'>{selected.activation}</span></p></div><div className='flex gap-2'><ListChecks className='mt-0.5 h-4 w-4 shrink-0 text-[#256e9f]' /><p><span className='font-semibold text-[#455b50]'>如何验证：</span><span className='text-[#6d7c75]'>{selected.validation}</span></p></div></div></section>
      <section className='py-4'><div className='flex items-center justify-between'><div><p className='text-xs text-[#7d8a84]'>已确认采用者</p><p className='mt-1 text-sm font-semibold text-[#2f443a]'>{selected.adoptedBy.length} 位协作者</p></div><AvatarStack names={selected.adoptedBy} /></div><div className='mt-3 flex items-center gap-2 text-xs text-[#6f7e77]'><RotateCcw className='h-4 w-4 text-[#44816b]' />下次回顾：<span className='font-semibold text-[#3f554b]'>{selected.review}</span></div></section>
    </div>
    <div className='border-t border-[#dde7e2] p-4'>
      {selected.state === '待确认' || selected.state === '需回顾' ? <div className='grid grid-cols-[1fr_1.5fr] gap-2'><button onClick={holdSelected} className='h-9 rounded-lg border border-[#d5e0da] text-xs font-semibold text-[#5e7067] hover:bg-[#f6f9f7]'>暂存回顾</button><button onClick={adoptSelected} className='inline-flex h-9 items-center justify-center gap-2 rounded-lg bg-[#0f7657] text-xs font-semibold text-white hover:bg-[#0b654a]'><Check className='h-4 w-4' />确认采用</button></div> : <div className='flex items-center justify-center gap-2 rounded-lg bg-[#edf8f2] py-2.5 text-xs font-semibold text-[#126d51]'><CheckCircle2 className='h-4 w-4' />这条判断已由用户确认</div>}
      <p className='mt-2 text-center text-[10px] leading-4 text-[#8b9791]'>采用后仍可在验证结果出现时限制或撤回。</p>
    </div>
  </div>

  return <div className='flex h-dvh min-h-[620px] overflow-hidden bg-[#f7faf8] text-[#172a22]'>
    <aside className='hidden w-[224px] shrink-0 flex-col border-r border-[#dfe8e3] bg-white px-3 py-4 md:flex'>
      <div className='mb-7 flex items-center gap-3 px-2'><TraceMark /><span className='text-lg font-semibold text-[#12251d]'>trace</span><span className='ml-auto rounded-full bg-[#e8f6ef] px-2 py-1 text-[10px] font-bold text-[#117153]'>BETA</span></div>
      <button className='mb-5 flex items-center gap-3 rounded-lg border border-[#dfe8e3] px-3 py-2.5 text-left hover:bg-[#f6faf8]'><span className='grid h-7 w-7 place-items-center rounded-md bg-[#133d30] text-[10px] font-bold text-white'>TW</span><span className='min-w-0 flex-1'><span className='block truncate text-xs font-semibold text-[#2a3e35]'>Trace workspace</span><span className='block truncate text-[10px] text-[#84918b]'>trace-web</span></span><ChevronDown className='h-4 w-4 text-[#89968f]' /></button>
      <nav className='space-y-1'>{navItems.map(item => <button key={item.id} onClick={() => setActiveNav(item.id)} className={'flex h-10 w-full items-center gap-3 rounded-lg px-3 text-sm transition ' + (activeNav === item.id ? 'bg-[#eaf7f1] font-semibold text-[#116a50]' : 'text-[#607168] hover:bg-[#f4f8f6] hover:text-[#20382d]')}><item.icon className='h-[17px] w-[17px]' /><span>{item.label}</span>{item.count && <span className='ml-auto grid h-5 min-w-5 place-items-center rounded-full bg-[#16805f] px-1.5 text-[10px] font-bold text-white'>{item.count}</span>}</button>)}</nav>
      <div className='mt-auto border-t border-[#e4ebe7] pt-4'><div className='flex items-center gap-2 px-3 text-[11px] text-[#64756c]'><span className='h-2 w-2 rounded-full bg-[#21a77c]' />Codex 已连接<span className='ml-auto font-mono text-[10px] text-[#98a29d]'>v0.3</span></div><div className='mt-4 flex items-center gap-2 px-2'><div className='grid h-8 w-8 place-items-center rounded-full bg-[#dcebe4] text-xs font-bold text-[#315d4d]'>L</div><div><p className='text-xs font-semibold text-[#30443b]'>林岚</p><p className='text-[10px] text-[#87938d]'>个人工作区</p></div><MoreHorizontal className='ml-auto h-4 w-4 text-[#91a099]' /></div></div>
    </aside>
    <div className='flex min-w-0 flex-1 flex-col'>
      <div className='flex h-14 shrink-0 items-center border-b border-[#dfe8e3] bg-white px-4 md:hidden'><TraceMark /><span className='ml-2 font-semibold'>trace</span><button aria-label='通知' className='ml-auto grid h-9 w-9 place-items-center rounded-lg text-[#607168]'><Bell className='h-4 w-4' /></button></div>
      <div className='flex min-h-0 flex-1'>
        <main className='min-w-0 flex-1 overflow-y-auto'><div className='mx-auto w-full max-w-[980px] px-4 py-6 sm:px-6 lg:px-8 lg:py-7'>
          {notice && <div className='mb-5 flex items-start gap-3 rounded-lg border border-[#c8e7d8] bg-[#edfaf4] px-4 py-3 text-sm text-[#17694f]'><CheckCircle2 className='mt-0.5 h-4 w-4 shrink-0' /><span className='flex-1 leading-5'>{notice}</span><button onClick={() => setNotice('')} aria-label='关闭提示'><X className='h-4 w-4' /></button></div>}
          {mainContent}
        </div></main>
        {showInspector && <aside className='hidden w-[360px] shrink-0 border-l border-[#dfe8e3] xl:block'>{detailPanel}</aside>}
      </div>
      <nav className='grid h-16 shrink-0 grid-cols-6 border-t border-[#dfe8e3] bg-white md:hidden'>{navItems.map(item => <button key={item.id} onClick={() => setActiveNav(item.id)} className={'flex flex-col items-center justify-center gap-1 text-[10px] ' + (activeNav === item.id ? 'font-semibold text-[#126f52]' : 'text-[#7b8982]')}><item.icon className='h-4 w-4' />{item.label}</button>)}</nav>
    </div>
    {showInspector && mobileDetailOpen && <div className='fixed inset-0 z-40 bg-[#10251d]/30 xl:hidden' onClick={() => setMobileDetailOpen(false)}><aside className='ml-auto h-full w-full max-w-[390px] shadow-2xl' onClick={event => event.stopPropagation()}>{detailPanel}</aside></div>}
    {recordOpen && <div className='fixed inset-0 z-50 grid place-items-center bg-[#10251d]/35 p-4' onClick={() => setRecordOpen(false)}>
      <form onSubmit={createCandidate} onClick={event => event.stopPropagation()} className='w-full max-w-lg rounded-lg border border-[#d9e5df] bg-white shadow-2xl'>
        <div className='flex items-start justify-between border-b border-[#e2eae6] px-5 py-4'><div><h2 className='text-base font-semibold text-[#1e3329]'>先接住这个瞬间</h2><p className='mt-1 text-xs text-[#7d8a84]'>保留原话与现场，不急着总结成结论。</p></div><button type='button' onClick={() => setRecordOpen(false)} className='grid h-8 w-8 place-items-center rounded-md text-[#77857e] hover:bg-[#f2f7f4]'><X className='h-4 w-4' /></button></div>
        <div className='space-y-4 px-5 py-5'><label className='block'><span className='mb-2 block text-xs font-semibold text-[#40554b]'>你现在的原话</span><textarea name='signal' required autoFocus rows={4} placeholder='例如：我说不清哪里不对，但这个方向可能会让人误解…' className='w-full resize-none rounded-lg border border-[#d7e3dd] px-3 py-2.5 text-sm leading-6 outline-none placeholder:text-[#9ca7a2] focus:border-[#5aaa8c] focus:ring-2 focus:ring-[#e0f4eb]' /></label><label className='block'><span className='mb-2 block text-xs font-semibold text-[#40554b]'>当前工作范围</span><input name='area' placeholder='例如：官网改版 / Research agent' className='h-10 w-full rounded-lg border border-[#d7e3dd] px-3 text-sm outline-none placeholder:text-[#9ca7a2] focus:border-[#5aaa8c] focus:ring-2 focus:ring-[#e0f4eb]' /></label><div className='flex gap-2 border-l-2 border-[#74bba0] bg-[#f3faf6] px-3 py-2.5 text-xs leading-5 text-[#607168]'><ShieldCheck className='mt-0.5 h-4 w-4 shrink-0 text-[#187b5d]' />这会创建待确认候选，不会自动发布为能力，也不会保存完整对话。</div></div>
        <div className='flex justify-end gap-2 border-t border-[#e2eae6] px-5 py-4'><button type='button' onClick={() => setRecordOpen(false)} className='h-9 rounded-lg px-3 text-sm font-medium text-[#65756d] hover:bg-[#f3f7f5]'>取消</button><button type='submit' className='h-9 rounded-lg bg-[#0f7657] px-4 text-sm font-semibold text-white hover:bg-[#0a6047]'>保留现场</button></div>
      </form>
    </div>}
  </div>
}
